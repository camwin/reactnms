import { useEffect, useState } from 'react';
import { Settings as SettingsIcon, Database } from 'lucide-react';

const API = import.meta.env.VITE_API_URL || 'http://localhost:3001';

export default function Settings() {
  const [netboxUrl, setNetboxUrl] = useState('');
  const [netboxToken, setNetboxToken] = useState('');
  const [netboxTag, setNetboxTag] = useState('');
  const [netboxRole, setNetboxRole] = useState('');
  const [credentials, setCredentials] = useState<any[]>([]);
  const [status, setStatus] = useState('');
  const [credName, setCredName] = useState('');
  const [credVersion, setCredVersion] = useState<'2c' | '3'>('2c');
  const [credCommunity, setCredCommunity] = useState('public');
  const [credUser, setCredUser] = useState('');
  const [credAuth, setCredAuth] = useState('');
  const [credPriv, setCredPriv] = useState('');

  useEffect(() => {
    fetch(`${API}/api/discovery/config`)
      .then((r) => r.json())
      .then((cfg) => {
        setNetboxUrl(cfg.netbox?.url || '');
        setNetboxToken(cfg.netbox?.token || '');
        setNetboxTag(cfg.netbox?.tag || '');
        setNetboxRole(cfg.netbox?.role || '');
        setCredentials(cfg.credentials || []);
      })
      .catch(() => {});
  }, []);

  async function save() {
    setStatus('Saving…');
    try {
      const cur = await (await fetch(`${API}/api/discovery/config`)).json();
      const resp = await fetch(`${API}/api/discovery/config`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...cur,
          netbox: { url: netboxUrl, token: netboxToken, tag: netboxTag, role: netboxRole },
          credentials,
        }),
      });
      if (!resp.ok) throw new Error(await resp.text());
      setStatus('Saved');
      setTimeout(() => setStatus(''), 2000);
    } catch (e: any) {
      setStatus('Failed: ' + e.message);
    }
  }

  function addCred() {
    const id = Date.now().toString();
    const entry: any = { id, name: credName || (credVersion === '2c' ? credCommunity : credUser), version: credVersion };
    if (credVersion === '2c') entry.community = credCommunity;
    else {
      entry.user = credUser;
      entry.authKey = credAuth;
      entry.privKey = credPriv;
    }
    setCredentials([...credentials, entry]);
    setCredName('');
    setCredCommunity('public');
    setCredUser('');
    setCredAuth('');
    setCredPriv('');
  }

  function removeCred(id: string) {
    setCredentials(credentials.filter((c) => c.id !== id));
  }

  return (
    <div>
      <div className="page-header">
        <h1><SettingsIcon size={24} style={{ verticalAlign: 'middle', marginRight: 8 }} />Settings</h1>
      </div>

      <div className="card">
        <h3><Database size={18} /> NetBox integration</h3>
        <p style={{ color: '#94a3b8', fontSize: '0.9rem' }}>Used for discovery import and topology intent. Token is stored on the backend.</p>
        <div style={{ display: 'grid', gap: 8, maxWidth: 480 }}>
          <input placeholder="NetBox URL" value={netboxUrl} onChange={(e) => setNetboxUrl(e.target.value)} style={inputStyle} />
          <input placeholder="API token" type="password" value={netboxToken} onChange={(e) => setNetboxToken(e.target.value)} style={inputStyle} />
          <input placeholder="Tag (optional)" value={netboxTag} onChange={(e) => setNetboxTag(e.target.value)} style={inputStyle} />
          <input placeholder="Role (optional)" value={netboxRole} onChange={(e) => setNetboxRole(e.target.value)} style={inputStyle} />
          <button className="btn-primary" onClick={save}>Save NetBox settings</button>
          {status && <span style={{ color: '#94a3b8' }}>{status}</span>}
        </div>
      </div>

      <div className="card" style={{ marginTop: 16 }}>
        <h3>SNMP credential bank</h3>
        <p style={{ color: '#94a3b8', fontSize: '0.9rem' }}>Tried in order during discovery. Supports v2c and v3.</p>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 8 }}>
          <input placeholder="Name" value={credName} onChange={(e) => setCredName(e.target.value)} style={inputStyle} />
          <select value={credVersion} onChange={(e) => setCredVersion(e.target.value as any)} style={inputStyle}>
            <option value="2c">v2c</option>
            <option value="3">v3</option>
          </select>
          {credVersion === '2c' ? (
            <input placeholder="Community" value={credCommunity} onChange={(e) => setCredCommunity(e.target.value)} style={inputStyle} />
          ) : (
            <>
              <input placeholder="User" value={credUser} onChange={(e) => setCredUser(e.target.value)} style={inputStyle} />
              <input placeholder="Auth key" value={credAuth} onChange={(e) => setCredAuth(e.target.value)} style={inputStyle} />
              <input placeholder="Priv key" value={credPriv} onChange={(e) => setCredPriv(e.target.value)} style={inputStyle} />
            </>
          )}
          <button className="btn-secondary" onClick={addCred}>Add credential</button>
        </div>
        {credentials.length === 0 ? (
          <p style={{ color: '#94a3b8' }}>No credentials yet.</p>
        ) : (
          <ul style={{ listStyle: 'none', padding: 0 }}>
            {credentials.map((c) => (
              <li key={c.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px solid #334155' }}>
                <span>{c.name} ({c.version}) {c.community || c.user}</span>
                <button onClick={() => removeCred(c.id)} style={{ background: 'none', border: 'none', color: '#f87171', cursor: 'pointer' }}>Remove</button>
              </li>
            ))}
          </ul>
        )}
        <button className="btn-primary" style={{ marginTop: 8 }} onClick={save}>Save credentials</button>
      </div>
    </div>
  );
}

const inputStyle: React.CSSProperties = {
  padding: '6px 8px',
  background: '#1e293b',
  border: '1px solid #334155',
  color: '#e2e8f0',
  borderRadius: 4,
};
