import { useEffect, useState } from 'react';
import { Radar, Play, Clock, Plus, Trash2 } from 'lucide-react';

const API = import.meta.env.VITE_API_URL || 'http://localhost:3001';

export default function Discovery() {
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState('');

  // Subnets
  const [subnets, setSubnets] = useState<string[]>([]);
  const [newSubnet, setNewSubnet] = useState('');

  // SNMP
  const [community, setCommunity] = useState('public');

  // Schedule
  const [scheduleEnabled, setScheduleEnabled] = useState(false);
  const [cron, setCron] = useState('0 */6 * * *');

  async function load() {
    try {
      const [cfgRes, resRes] = await Promise.all([
        fetch(`${API}/api/discovery/config`),
        fetch(`${API}/api/discovery/results`),
      ]);
      const cfg = await cfgRes.json();
      const res = await resRes.json();

      setSubnets(cfg.subnets || []);
      setCommunity(cfg.community || 'public');
      setScheduleEnabled(!!cfg.schedule?.enabled);
      setCron(cfg.schedule?.cron || '0 */6 * * *');
      setResults(res.results || []);
    } catch (e: any) {
      setStatus('Failed to load config: ' + e.message);
    }
  }

  useEffect(() => { load(); }, []);

  async function saveConfig() {
    setStatus('Saving…');
    try {
      await fetch(`${API}/api/discovery/config`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subnets,
          community,
          schedule: { enabled: scheduleEnabled, cron },
        }),
      });
      setStatus('Saved');
      setTimeout(() => setStatus(''), 2000);
    } catch (e: any) {
      setStatus('Save failed: ' + e.message);
    }
  }

  function addSubnet() {
    const s = newSubnet.trim();
    if (!s) return;
    if (!subnets.includes(s)) setSubnets([...subnets, s]);
    setNewSubnet('');
  }

  function removeSubnet(s: string) {
    setSubnets(subnets.filter((x) => x !== s));
  }

  async function runScan() {
    setLoading(true);
    setStatus('Scanning…');
    try {
      const resp = await fetch(`${API}/api/discovery/scan`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subnets, community }),
      });
      const data = await resp.json();
      setStatus(`Found ${data.count || 0} devices`);
      await load();
    } catch (e: any) {
      setStatus('Scan failed: ' + e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="discovery-page">
      <div className="page-header">
        <h1><Radar size={28} style={{ verticalAlign: 'middle', marginRight: 8 }} />Discovery</h1>
        <p>Add subnets and schedule scans. NetBox settings are under Settings.</p>
        {status && <div style={{ marginTop: 8, color: '#94a3b8' }}>{status}</div>}
      </div>

      {/* Subnets */}
      <div className="card" style={{ marginBottom: 16 }}>
        <h3>Subnets to Scan</h3>
        <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
          <input
            value={newSubnet}
            onChange={(e) => setNewSubnet(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && addSubnet()}
            placeholder="192.168.1.0/24"
            style={{ flex: 1 }}
          />
          <button className="btn-secondary" onClick={addSubnet}><Plus size={16} /> Add</button>
        </div>
        {subnets.length === 0 ? (
          <p style={{ color: '#94a3b8' }}>No subnets added yet.</p>
        ) : (
          <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
            {subnets.map((s) => (
              <li key={s} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px solid #334155' }}>
                <code>{s}</code>
                <button onClick={() => removeSubnet(s)} style={{ background: 'none', border: 'none', color: '#f87171', cursor: 'pointer' }}>
                  <Trash2 size={16} />
                </button>
              </li>
            ))}
          </ul>
        )}
        <div style={{ display: 'flex', gap: 12, marginTop: 12, alignItems: 'center' }}>
          <label>SNMP Community</label>
          <input value={community} onChange={(e) => setCommunity(e.target.value)} style={{ width: 140 }} />
          <button className="btn-primary" onClick={runScan} disabled={loading || subnets.length === 0}>
            <Play size={16} /> {loading ? 'Scanning…' : 'Scan Now'}
          </button>
          <button className="btn-secondary" onClick={saveConfig}>Save</button>
        </div>
      </div>

      {/* Schedule */}
      <div className="card" style={{ marginBottom: 16 }}>
        <h3><Clock size={18} /> Schedule</h3>
        <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <input type="checkbox" checked={scheduleEnabled} onChange={(e) => setScheduleEnabled(e.target.checked)} />
          Enable scheduled discovery
        </label>
        <div style={{ marginTop: 8 }}>
          <label>Cron expression</label>
          <input value={cron} onChange={(e) => setCron(e.target.value)} style={{ width: 200, marginLeft: 8 }} placeholder="0 */6 * * *" />
          <span style={{ marginLeft: 8, color: '#94a3b8', fontSize: '0.85rem' }}>e.g. every 6 hours</span>
        </div>
        <button className="btn-secondary" style={{ marginTop: 8 }} onClick={saveConfig}>Update Schedule</button>
      </div>

      {/* Results */}
      <div className="card">
        <h3>Discovered Devices {results.length > 0 && `(${results.length})`}</h3>
        {results.length === 0 ? (
          <p style={{ color: '#94a3b8' }}>No devices discovered yet. Add subnets and scan, or import from NetBox.</p>
        ) : (
          <div className="table-container">
            <table className="devices-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>IP</th>
                  <th>Description</th>
                  <th>Subnet</th>
                  <th>Discovered</th>
                </tr>
              </thead>
              <tbody>
                {results.map((d, i) => (
                  <tr key={i}>
                    <td><strong>{d.sysName || d.ip}</strong></td>
                    <td className="mono">{d.ip}</td>
                    <td style={{ fontSize: '0.85rem', maxWidth: 300, overflow: 'hidden', textOverflow: 'ellipsis' }}>{d.sysDescr}</td>
                    <td>{d.subnet}</td>
                    <td style={{ fontSize: '0.8rem', color: '#94a3b8' }}>{new Date(d.discoveredAt).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
